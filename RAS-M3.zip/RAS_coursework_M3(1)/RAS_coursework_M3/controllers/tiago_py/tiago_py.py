import os
import shapely.geometry
from shapely.geometry import Polygon
from pyperplan.pddl.parser import Parser
from pyperplan.grounding import ground
from pyperplan.search.searchspace import make_root_node
from pyperplan.search import astar_search
from pyperplan.heuristics.blind import BlindHeuristic

from controller import Robot
from keyboardreader import KeyboardReader

# Define polygons and calculate their centroids for navigation targets
goal_areas = {
    'red': Polygon([
        (3.18, 2.12),
        (4.19, 2.12),
        (4.19, 3.90),
        (3.18, 3.90)
    ]),
    'green': Polygon([
        (3.18, -4.86),
        (4.19, -4.86),
        (4.19, -3.02),
        (3.18, -3.02)
    ]),
    'ducks': Polygon([
        (-2.59, 3.90),
        (-3.07, 3.08),
        (-3.55, 3.37),
        (-3.09, 4.19)
    ]),
    'balls': Polygon([
        (-2.55, -3.67),
        (-2.25, -4.20),
        (-3.09, -4.67),
        (-3.34, -4.15)
    ])
}

GOAL_COORDINATES = {goal: area.centroid.coords[0] for goal, area in goal_areas.items()}

def ordered_node_astar(node, h, node_tiebreaker):
    f = node.g + h
    print(f"Calculating node with g: {node.g}, h: {h}, tiebreaker: {node_tiebreaker}, f: {f}")
    return (f, h, node_tiebreaker, node)

def initialize_robot():
    """Initializes the robot and its devices."""
    robot = Robot()
    timestep = int(robot.getBasicTimeStep())
    l_motor = robot.getDevice("wheel_left_joint")
    r_motor = robot.getDevice("wheel_right_joint")
    lidar = robot.getDevice("lidar")
    compass = robot.getDevice("compass")
    gps = robot.getDevice("gps")

    lidar.enable(timestep)
    compass.enable(timestep)
    gps.enable(timestep)
    l_motor.setPosition(float('inf'))
    r_motor.setPosition(float('inf'))
    l_motor.setVelocity(0)
    r_motor.setVelocity(0)

    return robot, l_motor, r_motor, lidar, compass, gps, timestep

def detect_obstacles(lidar):
    """Detects obstacles using LiDAR data."""
    ranges = lidar.getRanges()
    obstacle_positions = []
    for i, distance in enumerate(ranges):
        if distance < 0.8:  
            angle = i * lidar.getFov() / len(ranges)
            obstacle_positions.append((distance, angle))
    return obstacle_positions

def avoid_obstacles(robot, l_motor, r_motor, lidar):
    """Avoids obstacles by modifying motor velocities."""
    obstacles = detect_obstacles(lidar)
    if obstacles:
        l_motor.setVelocity(0)
        r_motor.setVelocity(0)
        robot.step(100)  
        l_motor.setVelocity(-2)  
        r_motor.setVelocity(2)  
        robot.step(500) 
        return True
    return False

def adjust_to_heading(robot, desired_heading, l_motor, r_motor, compass, tolerance=5):
    """Adjusts the robot's heading to the desired heading."""
    current_heading = compass.getValues()[0]  #
    while abs(desired_heading - current_heading) > tolerance:
        error = desired_heading - current_heading
        if error > 0:
            l_motor.setVelocity(-1) 
            r_motor.setVelocity(1)  
        else:
            l_motor.setVelocity(1)  
            r_motor.setVelocity(-1)  
        robot.step(100)  
        current_heading = compass.getValues()[0]
    # Stop rotation
    l_motor.setVelocity(0)
    r_motor.setVelocity(0)
    robot.step(100)  

def run_planner(domain_file, problem_file):
    """Runs the Pyperplan planner with the given domain and problem files."""
    print("Starting the planner...")
    parser = Parser(domain_file, problem_file)
    print("Parsing domain...")
    domain = parser.parse_domain()
    print("Domain parsed successfully.")

    print("Parsing problem...")
    problem = parser.parse_problem(domain)
    print("Problem parsed successfully.")

    print("Grounding the problem...")
    task = ground(problem)
    print("Problem grounded successfully.")

    heuristic = BlindHeuristic(task)
    print("Heuristic initialized.")

    print("Searching for a plan...")
    solution = astar_search(task, heuristic, ordered_node_astar)
    if solution:
        print("Plan found:")
        for action in solution:
            print(action.name)
        return solution
    else:
        print("No valid plan found.")
        return None

def execute_plan(plan, robot, l_motor, r_motor, lidar, compass, gps):
    """Executes the given plan while avoiding obstacles and navigating to goals."""
    for action in plan:
        print(f"Executing: {action.name}")
        if "move" in action.name:
            goal_name = action.name.split()[-1]
            target_x, target_y = GOAL_COORDINATES[goal_name]
            desired_heading = calculate_heading(gps.get_coordinates(), (target_x, target_y))
            adjust_to_heading(robot, desired_heading, l_motor, r_motor, compass)
            while True:
                if not avoid_obstacles(robot, l_motor, r_motor, lidar):
                    l_motor.setVelocity(5)
                    r_motor.setVelocity(5)
                    robot.step(1000)  # simulate movement
                    x, y = gps.get_coordinates()
                    print(f"Robot's current coordinates: x={x}, y={y}")
                    if (x, y) == (target_x, target_y):
                        print(f"Reached goal {goal_name} at ({x}, {y})")
                        break
                l_motor.setVelocity(0)
                r_motor.setVelocity(0)
                robot.step(100)
        print(f"Action {action.name} completed.")

def main():
    robot, l_motor, r_motor, lidar, compass, gps, timestep = initialize_robot()
    keyboard = KeyboardReader(timestep)
    domain_file = 'warehouse_domain.pddl'
    problem_file = 'warehouse_problem.pddl'
    task_queue = []

    while robot.step(timestep) != -1:
        command = keyboard.get_command()
        if command:
            new_goals = command.split(',')
            print(f"New tasks received: {new_goals}")
            task_queue.extend(new_goals)

        if task_queue:
            current_task = task_queue.pop(0)
            print(f"Processing task: {current_task}")
            plan = run_planner(domain_file, problem_file)
            if plan:
                execute_plan(plan, robot, l_motor, r_motor, lidar, compass, gps)
            else:
                print("No valid plan found.")
        else:
            print("Task queue is empty, no planning performed.")

if __name__ == "__main__":
    main()